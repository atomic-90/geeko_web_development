from django.urls import path
from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("about", views.about, name="about"),
    path("contact", views.contact, name="contact"),
    path("help", views.help, name="help"),
    path("community", views.community, name="community"),
    path("projects", views.projects, name="projects"),
    path("profile", views.profile, name="profile"),
    path("upload", views.upload, name="upload"),
    path("view_data", views.view_data, name="view_data"),
    path("register", views.register_view, name="register_user"),
    path("testing", views.testing, name="testing"),
    path("login", views.login_view, name="login"),
    path("logout/", views.logout_view, name="logout"),
    path("submit_contact_ajax", views.submit_contact_ajax, name="submit_contact_ajax"),
    path('update_profile_ajax/', views.update_profile_ajax, name='update_profile_ajax'),
    path('delete_profile_ajax/', views.delete_profile_ajax, name='delete_profile_ajax'),
    path("create_discussion/", views.create_discussion, name="create_discussion"),
    path("add_reply/", views.add_reply, name="add_reply"),
    path("get_discussions/", views.get_discussions, name="get_discussions"),
]