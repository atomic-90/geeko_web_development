from django.contrib import admin
from .models import User, Upload, ContactSubmission, Discussion, Reply

# Register your models here.
admin.site.register(Upload)
admin.site.register(User)
admin.site.register(ContactSubmission)
admin.site.register(Discussion)
admin.site.register(Reply)