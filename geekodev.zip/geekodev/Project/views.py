from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .forms import UploadForm
from .models import User, Upload, ContactSubmission, Discussion, Reply
import json
import re

# Home page
def home(request):
    return render(request, 'index.html')

def about(request):
    return render(request, 'about.html')

def contact(request):
    return render(request, 'contact.html')

@csrf_exempt
def submit_contact_ajax(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            required_fields = ["firstName", "surname", "email", "address", "country", "message", "submittedAt"]
            for field in required_fields:
                if not data.get(field):
                    return JsonResponse({"status": "error", "message": f"{field} is required."})

            ContactSubmission.objects.create(
                first_name=data.get("firstName"),
                surname=data.get("surname"),
                email=data.get("email"),
                address=data.get("address"),
                country=data.get("country"),
                message=data.get("message"),
                submitted_at=data.get("submittedAt"),
            )

            return JsonResponse({"status": "success"})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})
    return JsonResponse({"status": "error", "message": "Invalid request method"})

def help(request):
    return render(request, 'help.html')

def community(request):
    return render(request, 'community.html')

# Decorator for login check in AJAX
def ajax_login_required(view_func):
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return JsonResponse({"status": "unauthenticated", "message": "You need to log in."}, status=401)
        return view_func(request, *args, **kwargs)
    return wrapper

@ajax_login_required
def create_discussion(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            title = data.get("title")
            if not title or len(title.strip()) < 5:
                return JsonResponse({"status": "error", "message": "Title must be at least 5 characters long."})
            discussion = Discussion.objects.create(title=title.strip(), author=request.user)
            return JsonResponse({"status": "success", "id": discussion.id})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})
    return JsonResponse({"status": "error", "message": "Invalid request."})

@ajax_login_required
def add_reply(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            discussion_id = data.get("discussion_id")
            text = data.get("text")

            if not discussion_id or not text or len(text.strip()) < 3:
                return JsonResponse({"status": "error", "message": "Valid reply text is required."})

            discussion = Discussion.objects.get(id=discussion_id)
            Reply.objects.create(discussion=discussion, author=request.user, text=text.strip())
            return JsonResponse({"status": "success"})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})
    return JsonResponse({"status": "error", "message": "Invalid request."})

def get_discussions(request):
    discussions = Discussion.objects.all().order_by("-created_at")
    data = []
    for disc in discussions:
        replies = list(disc.replies.all().values("author__username", "text", "created_at"))
        data.append({
            "id": disc.id,
            "title": disc.title,
            "author": disc.author.username,
            "created_at": disc.created_at,
            "replies": replies,
        })
    return JsonResponse({"status": "success", "data": data})

def projects(request):
    uploads = Upload.objects.all()
    return render(request, 'projects.html', {'results': uploads})

@login_required
def profile(request):
    user_uploads = Upload.objects.filter(user=request.user)
    return render(request, 'profile.html', {
        'user': request.user,
        'uploads': user_uploads,
    })

@login_required
def update_profile_ajax(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            new_username = data.get("username")

            if not new_username or len(new_username) < 3:
                return JsonResponse({"status": "error", "message": "Username must be at least 3 characters long."})
            if User.objects.filter(username=new_username).exclude(id=request.user.id).exists():
                return JsonResponse({"status": "error", "message": "Username is already taken."})

            request.user.username = new_username
            request.user.save()
            return JsonResponse({"status": "success"})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)})
    return JsonResponse({"status": "error", "message": "Invalid request"})

@login_required
def delete_profile_ajax(request):
    if request.method == 'POST':
        user = request.user
        logout(request)
        user.delete()
        return JsonResponse({"status": "success"})
    return JsonResponse({"status": "error", "message": "Invalid request"})

def view_data(request):
    return render(request, 'view_data.html')

def testing(request):
    Users = User.objects.all()
    return render(request, 'testing.html', {"users": Users})

# Q4. User Registration
def register_view(request):
    if request.user.is_authenticated:
        return redirect('/')

    if request.method == 'POST':
        first_name = request.POST.get('first_name', '').strip()
        last_name = request.POST.get('last_name', '').strip()
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '').strip()

        if not all([first_name, last_name, username, password]):
            messages.error(request, "All fields are required.")
            return redirect('/register')

        if len(username) < 3 or len(password) < 6:
            messages.error(request, "Username must be at least 3 characters and password at least 6.")
            return redirect('/register')

        if User.objects.filter(username=username).exists():
            messages.error(request, 'Username already taken')
            return redirect('/register')

        try:
            user = User.objects.create_user(
                username=username,
                password=password,
                first_name=first_name,
                last_name=last_name
            )
            login(request, user)
            messages.success(request, 'Account created successfully!')
            return redirect('/')
        except Exception as e:
            messages.error(request, f'Error creating account: {str(e)}')

    return render(request, 'register_user.html')

# Q4. User Logout
@login_required
def logout_view(request):
    logout(request)
    messages.success(request, 'Logged out successfully!')
    return redirect('/')

# Q4. User Login
def login_view(request):
    if request.user.is_authenticated:
        return redirect('/')

    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '').strip()

        if not username or not password:
            messages.error(request, "Username and password are required.")
            return redirect('/login')

        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            messages.success(request, 'Login successful!')
            return redirect('/')
        else:
            messages.error(request, 'Invalid username or password.')

    return render(request, 'login.html')

@login_required
def upload(request):
    if request.method == 'POST':
        form = UploadForm(request.POST, request.FILES)
        if form.is_valid():
            upload = form.save(commit=False)
            upload.user = request.user
            upload.save()
            messages.success(request, 'Project uploaded successfully!')
            return redirect('/upload')
        else:
            messages.error(request, 'Upload failed. Please ensure all required fields are valid.')
    else:
        form = UploadForm()
    return render(request, 'upload.html', {'form': form})