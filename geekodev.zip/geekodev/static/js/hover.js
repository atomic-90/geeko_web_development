document.addEventListener("DOMContentLoaded", function () {
  // Select all feature cards
  const featureCards = document.querySelectorAll(".row.g-0");

  featureCards.forEach((card) => {
    // Add hover effect
    card.addEventListener("mouseover", function () {
      card.style.transform = "scale(1.075)";
      card.style.boxShadow = "0 10px 20px rgba(0, 0, 0, 0.3)";
      card.style.transition = "all 0.3s ease-in-out";
    });

    // Remove hover effect
    card.addEventListener("mouseout", function () {
      card.style.transform = "scale(1)";
      card.style.boxShadow = "0 4px 8px rgba(0, 0, 0, 0.1)";
    });
  });
});
