document.addEventListener("DOMContentLoaded", function () {
  const form = document.querySelector(".upload-form");

  form.addEventListener("submit", function (event) {
    let isValid = true;

    // Get form values
    let title = document.getElementById("FormControlInput1").value.trim();
    let description = document
      .getElementById("FormControlTextarea1")
      .value.trim();
    let fileInput = document.getElementById("formFile");
    let file = fileInput.files[0];

    // Title validation (must not be empty)
    if (title.length === 0) {
      showError("FormControlInput1", "Project title is required.");
      isValid = false;
    } else {
      hideError("FormControlInput1");
    }

    // Description validation (minimum 10 characters)
    if (description.length < 10) {
      showError(
        "FormControlTextarea1",
        "Description must be at least 10 characters long."
      );
      isValid = false;
    } else {
      hideError("FormControlTextarea1");
    }

    // File validation
    if (!file) {
      showError("formFile", "Please select a file to upload.");
      isValid = false;
    } else {
      let allowedTypes = [
        "image/jpeg",
        "image/png",
        "application/pdf",
        "application/zip",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      ];
      if (!allowedTypes.includes(file.type)) {
        showError(
          "formFile",
          "Invalid file type. Only JPG, PNG, PDF, ZIP, and DOCX files are allowed."
        );
        isValid = false;
      } else {
        hideError("formFile");
      }
    }

    // Prevent form submission if validation fails
    if (!isValid) {
      event.preventDefault();
      return;
    }

    // Show success message
    event.preventDefault(); // Prevent default submission for demo
    showSuccessMessage();
    form.reset(); // Clear form after successful submission
  });

  // Function to show error messages
  function showError(inputId, message) {
    let inputElement = document.getElementById(inputId);
    let errorElement = inputElement.nextElementSibling;

    if (!errorElement || !errorElement.classList.contains("error-message")) {
      errorElement = document.createElement("span");
      errorElement.classList.add("error-message");
      inputElement.parentNode.insertBefore(
        errorElement,
        inputElement.nextSibling
      );
    }

    errorElement.innerText = message;
    errorElement.style.color = "red";
    errorElement.style.fontSize = "12px";
    errorElement.style.display = "block";

    // Highlight input field in red
    inputElement.style.border = "2px solid red";
  }

  // Function to hide error messages
  function hideError(inputId) {
    let inputElement = document.getElementById(inputId);
    let errorElement = inputElement.nextElementSibling;

    if (errorElement && errorElement.classList.contains("error-message")) {
      errorElement.style.display = "none";
    }

    // Remove red border
    inputElement.style.border = "2px solid #ccc";
  }

  // Function to show success message
  function showSuccessMessage() {
    let successMessage = document.createElement("p");
    successMessage.innerText = "File uploaded successfully!";
    successMessage.style.color = "green";
    successMessage.style.fontSize = "16px";
    successMessage.style.fontWeight = "bold";
    successMessage.style.textAlign = "center";
    successMessage.style.marginTop = "15px";

    form.appendChild(successMessage);

    // Remove success message after 3 seconds
    setTimeout(() => {
      successMessage.remove();
    }, 3000);
  }
});
