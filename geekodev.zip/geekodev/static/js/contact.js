document.addEventListener("DOMContentLoaded", function () {
  const form = document.querySelector(".contact-form");

  form.addEventListener("submit", function (event) {
    event.preventDefault();

    let isValid = true;

    let formData = {
      firstName: document.getElementById("fname").value.trim(),
      surname: document.getElementById("sname").value.trim(),
      email: document.getElementById("email").value.trim(),
      address: document.getElementById("Address1").value.trim(),
      country: document.getElementById("Country").value.trim(),
      message: document.getElementById("message").value.trim(),
      submittedAt: new Date().toLocaleString(),
    };

    let nameRegex = /^[A-Za-z]+$/;
    let emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!nameRegex.test(formData.firstName)) {
      showError("fname", "First name should only contain letters.");
      isValid = false;
    } else hideError("fname");

    if (!nameRegex.test(formData.surname)) {
      showError("sname", "Surname should only contain letters.");
      isValid = false;
    } else hideError("sname");

    if (!emailRegex.test(formData.email)) {
      showError("email", "Please enter a valid email address.");
      isValid = false;
    } else hideError("email");

    if (formData.address.length > 0 && formData.address.length < 5) {
      showError("Address1", "Address should be at least 5 characters long.");
      isValid = false;
    } else hideError("Address1");

    if (formData.country === "") {
      showError("Country", "Country is required.");
      isValid = false;
    } else hideError("Country");

    if (formData.message.length < 10) {
      showError("message", "Message should be at least 10 characters long.");
      isValid = false;
    } else hideError("message");

    if (!isValid) {
      alert("Form submission failed. Please check the highlighted fields.");
      return;
    }

    // Save locally
    let submittedData = JSON.parse(localStorage.getItem("formData")) || [];
    submittedData.push(formData);
    localStorage.setItem("formData", JSON.stringify(submittedData));

    // Q2 AJAX to Django backend
    // Q3. 
    fetch("/submit_contact_ajax", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CSRFToken": getCookie("csrftoken"),
      },
      body: JSON.stringify(formData),
    })
      .then((response) => {
        if (!response.ok) throw new Error("Network error");
        return response.json();
      })
      .then((data) => {
        if (data.status === "success") {
          showSuccessMessage();
          form.reset();
        } else {
          alert("There was an error submitting the form.");
        }
      })
      .catch((error) => {
        console.error("AJAX error:", error);
        alert("An error occurred while submitting the form.");
      });
  });

  function showError(inputId, message) {
    let inputElement = document.getElementById(inputId);
    let errorElement = inputElement.nextElementSibling;

    if (!errorElement || !errorElement.classList.contains("error-message")) {
      errorElement = document.createElement("span");
      errorElement.classList.add("error-message");
      inputElement.parentNode.insertBefore(
        errorElement,
        inputElement.nextSibling
      );
    }

    errorElement.innerText = message;
    errorElement.style.color = "red";
    errorElement.style.fontSize = "12px";
    errorElement.style.display = "block";
    inputElement.style.border = "2px solid red";
  }

  function hideError(inputId) {
    let inputElement = document.getElementById(inputId);
    let errorElement = inputElement.nextElementSibling;

    if (errorElement && errorElement.classList.contains("error-message")) {
      errorElement.style.display = "none";
    }

    inputElement.style.border = "2px solid #ccc";
  }

  function showSuccessMessage() {
    alert("Form submitted successfully!");
  }

  function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== "") {
      const cookies = document.cookie.split(";");
      for (let i = 0; i < cookies.length; i++) {
        const cookie = cookies[i].trim();
        if (cookie.substring(0, name.length + 1) === name + "=") {
          cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
          break;
        }
      }
    }
    return cookieValue;
  }
});
