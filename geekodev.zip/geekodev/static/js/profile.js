// CSRF helper function
function getCookie(name) {
  let cookieValue = null;
  if (document.cookie && document.cookie !== "") {
    const cookies = document.cookie.split(";");
    for (let i = 0; i < cookies.length; i++) {
      const cookie = cookies[i].trim();
      if (cookie.substring(0, name.length + 1) === name + "=") {
        cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
        break;
      }
    }
  }
  return cookieValue;
}

// Q3. 1 or more JSON-based AJAX POST Request that perform some action to an entry in thedatabase, i.e. Create, Update, or Delete.
document.addEventListener("DOMContentLoaded", function () {
  const saveBtn = document.getElementById("saveProfileBtn");
  const deleteBtn = document.getElementById("deleteProfileBtn");

  if (saveBtn) {
    saveBtn.addEventListener("click", function () {
      const newUsername = document.getElementById("username").value.trim();

      if (!newUsername) {
        alert("Please enter a valid username.");
        return;
      }

      // Q2 - AJAX request to update profile
      fetch("/update_profile_ajax/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRFToken": getCookie("csrftoken"),
        },
        body: JSON.stringify({ username: newUsername }),
      })
        .then((res) => res.json())
        .then((data) => {
          if (data.status === "success") {
            alert("Profile updated!");
            location.reload(); // Refresh to show updated username
          } else {
            alert(data.message || "Error updating profile.");
          }
        })
        .catch((err) => {
          console.error("Error:", err);
          alert("An error occurred.");
        });
    });
  }

  // Q2 - AJAX request to delete profile
  if (deleteBtn) {
    deleteBtn.addEventListener("click", function () {
      fetch("/delete_profile_ajax/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRFToken": getCookie("csrftoken"),
        },
      })
        .then((res) => res.json())
        .then((data) => {
          if (data.status === "success") {
            alert("Your account has been deleted.");
            window.location.href = "/"; // Redirect to homepage
          } else {
            alert(data.message || "Error deleting account.");
          }
        })
        .catch((err) => {
          console.error("Error:", err);
          alert("An error occurred.");
        });
    });
  }
});
