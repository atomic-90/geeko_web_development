function getCookie(name) {
  let cookieValue = null;
  if (document.cookie && document.cookie !== "") {
    document.cookie.split(";").forEach((cookie) => {
      cookie = cookie.trim();
      if (cookie.substring(0, name.length + 1) === name + "=") {
        cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
      }
    });
  }
  return cookieValue;
}

// Create a new discussion
document.getElementById("postDiscussionBtn").addEventListener("click", () => {
  const title = document.getElementById("discussionTitle").value.trim();
  if (!title) {
    alert("Please enter a question.");
    return;
  }

  // Q3. 1 or more JSON-based AJAX GET Request.
  fetch("/create_discussion/", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-CSRFToken": getCookie("csrftoken"),
    },
    body: JSON.stringify({ title }),
  })
    .then((res) => res.json())
    .then((data) => {
      if (data.status === "unauthenticated") {
        window.location.href = "/login?next=/community";
      } else if (data.status === "success") {
        alert("Discussion created!");
        document.getElementById("discussionTitle").value = "";
        loadDiscussions();
      } else {
        alert("Failed to create discussion. Please try again.");
      }
    })
    .catch(() => alert("Something went wrong. Please try again."));
});

// Load all discussions
function loadDiscussions() {
  fetch("/get_discussions/")
    .then((res) => res.json())
    .then((data) => {
      const container = document.getElementById("discussionFeed");
      container.innerHTML = "";
      data.data.forEach((disc) => {
        const repliesHtml = disc.replies
          .map(
            (r) => `<p><strong>${r.author__username}:</strong> ${r.text}</p>`
          )
          .join("");
        container.innerHTML += `
          <div class="discussion-card mb-3 p-3 border rounded shadow-sm">
            <h5>${disc.title}</h5>
            <p>Started by <strong>${disc.author}</strong> on ${new Date(
          disc.created_at
        ).toLocaleString()}</p>
            <div class="replies">${repliesHtml}</div>
            <textarea class="form-control mb-2" id="reply-${
              disc.id
            }" placeholder="Your reply..."></textarea>
            <button class="btn btn-sm btn-outline-primary" onclick="sendReply(${
              disc.id
            })">Reply</button>
          </div>`;
      });
    })
    .catch(() => {
      document.getElementById("discussionFeed").innerHTML =
        "<p>Failed to load discussions.</p>";
    });
}

// Send a reply to a discussion
function sendReply(discussion_id) {
  const textarea = document.getElementById(`reply-${discussion_id}`);
  const text = textarea.value.trim();

  if (!text) {
    alert("Please enter a reply.");
    return;
  }

  // Q2 ajax request to add reply
  fetch("/add_reply/", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-CSRFToken": getCookie("csrftoken"),
    },
    body: JSON.stringify({ discussion_id, text }),
  })
    .then((res) => res.json())
    .then((data) => {
      if (data.status === "unauthenticated") {
        window.location.href = "/login?next=/community";
      } else if (data.status === "success") {
        alert("Reply posted!");
        textarea.value = "";
        loadDiscussions();
      } else {
        alert("Failed to post reply.");
      }
    })
    .catch(() => alert("Something went wrong. Please try again."));
}

// Initial load
window.onload = loadDiscussions;
