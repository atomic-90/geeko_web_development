document.addEventListener("DOMContentLoaded", function () {
  const header = document.querySelector("header");
  const navbar = document.querySelector("nav");
  const body = document.body;
  let lastScrollTop = 0;
  let isScrollingUp = true;

  // Ensure content does not overlap with the navbar
  const headerHeight = header.offsetHeight;
  body.style.paddingTop = `${headerHeight}px`;

  // Function to check if the user has reached the bottom of the page
  function isUserAtBottom() {
    return (
      window.innerHeight + window.scrollY >= document.body.offsetHeight - 10
    );
  }

  // Function to handle smooth navbar hiding/showing with fade effect
  function handleScroll() {
    let currentScrollTop = window.scrollY;
    let atBottom = isUserAtBottom();

    // If user is at the bottom of the page, fade out smoothly
    if (atBottom) {
      header.style.transition =
        "opacity 1.2s ease-in-out, transform 1s ease-in-out";
      header.style.opacity = "0";
      header.style.transform = "translateY(-50px)";
    }
    // If scrolling down (but not at bottom)
    else if (currentScrollTop > lastScrollTop && currentScrollTop > 50) {
      if (isScrollingUp) {
        header.style.transition =
          "opacity 0.8s ease-in-out, transform 0.8s ease-in-out";
        header.style.transform = "translateY(-100%)";
        header.style.opacity = "0.6"; // Partial fade when scrolling
        isScrollingUp = false;
      }
    }
    // If scrolling up
    else {
      if (!isScrollingUp || header.style.opacity === "0") {
        header.style.transition =
          "opacity 1s ease-in-out, transform 1s ease-in-out";
        header.style.transform = "translateY(0)";
        header.style.opacity = "1";
        isScrollingUp = true;
      }
    }
    lastScrollTop = currentScrollTop;
  }

  // Apply initial styles for smooth transitions and fade effect
  header.style.position = "fixed";
  header.style.top = "0";
  header.style.left = "0";
  header.style.width = "100%";
  header.style.zIndex = "1000";
  header.style.transition = "opacity 1s ease-in-out, transform 1s ease-in-out";
  header.style.opacity = "1";

  navbar.style.transition = "background-color 0.3s ease-in-out";

  // Add scroll event listener
  window.addEventListener("scroll", handleScroll);
});
