document.addEventListener("DOMContentLoaded", function () {
  const tableBody = document.getElementById("table-body");
  let submittedData = JSON.parse(localStorage.getItem("formData")) || []; // Load stored data

  // Function to display data in the table
  function displayData() {
    tableBody.innerHTML = ""; // Clear table before reloading

    if (submittedData.length === 0) {
      tableBody.innerHTML =
        "<tr><td colspan='8' style='text-align:center;'>No form submissions yet.</td></tr>";
      return;
    }

    submittedData.forEach((entry, index) => {
      let row = document.createElement("tr");

      Object.values(entry).forEach((text) => {
        let td = document.createElement("td");
        td.innerText = text;
        row.appendChild(td);
      });

      // Delete button
      let deleteCell = document.createElement("td");
      let deleteBtn = document.createElement("button");
      deleteBtn.innerText = "Delete";
      deleteBtn.onclick = function () {
        deleteEntry(index);
      };

      deleteCell.appendChild(deleteBtn);
      row.appendChild(deleteCell);
      tableBody.appendChild(row);
    });
  }

  // Function to delete an entry
  function deleteEntry(index) {
    submittedData.splice(index, 1); // Remove entry from array
    localStorage.setItem("formData", JSON.stringify(submittedData)); // Update storage
    displayData(); // Refresh table
  }

  displayData(); // Load data when page loads
});
